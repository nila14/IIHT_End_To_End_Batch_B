import { Component } from '@angular/core';
import { BaseComponent } from './base.component';

@Component({
  selector : 'my-inherited',
  template: `
  <div style='background-color: #abcdef'>
     {{val}}
     <tr *ngFor="let num of arr; let i = index">
          <td>{{num}}</td>
    </tr>
  </div>
`
})
export class DerivedComponent extends BaseComponent {}
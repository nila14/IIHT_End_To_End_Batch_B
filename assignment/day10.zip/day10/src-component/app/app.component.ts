import { Component } from '@angular/core';

import { Employee } from './employee'

const EMPLOYEE:Employee[]=[
  {id:1,name:'nila',salary:50000,department:'cse'},
  {id:2,name:'nisha',salary:100000,department:'aero'},
  {id:3,name:'jas',salary:30000,department:'IT'}

];
@Component({
  selector: 'my-app',
  template: `
    <h1>{{title}}</h1>
    <h2>My Employee</h2>
    <ul class="employee">
      <li *ngFor="let employee of employee"
        [class.selected]="employee === selectedEmployee"
        (click)="onSelect(employee)">
        <span class="badge">{{employee.id}}</span>
        <span class="badge">{{employee.name}}</span><span class="badge">{{employee.salary}}</span><span class="badge">{{employee.department}}</span> 
      </li>
    </ul>
    <employee-detail [employee]="selectedEmployee"></employee-detail>
  `,
  styles: [
    `
    .selected {
      background-color: #CFD8DC !important;
      color: white;
    }
    .employee {
      margin: 0 0 2em 0;
      list-style-type: none;
      padding: 0;
      width: 15em;
    }
    .employee li {
      cursor: pointer;
      position: relative;
      left: 0;
      background-color: #EEE;
      margin: .5em;
      padding: .3em 0;
      height: 1.6em;
      border-radius: 4px;
    }
    .employee li.selected:hover {
      background-color: #BBD8DC !important;
      color: white;
    }
    .employee li:hover {
      color: #607D8B;
      background-color: #DDD;
      left: .1em;
    }
    .employee .text {
      position: relative;
      top: -3px;
    }
    .employee .badge {
      display: inline-block;
      font-size: small;
      color: white;
      padding: 0.8em 0.7em 0 0.7em;
      background-color: #607D8B;
      line-height: 1em;
      position: relative;
      left: -1px;
      top: -4px;
      height: 1.8em;
      margin-right: .8em;
      border-radius: 4px 0 0 4px;
    }
  `]
})
export class AppComponent {
  title = 'Employee details';
  employee=EMPLOYEE;
  selectedEmployee: Employee;

  onSelect(employee: Employee): void {
    this.selectedEmployee= employee;
  }
}

package com.example.jpa.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.jpa.model.UserProfile;
import com.example.jpa.repository.UserProfileRepository;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api")
public class UserProfileController {
	
	@Autowired
	UserProfileRepository repository;
	
	@GetMapping("/user_profile")
	public List<UserProfile> getAllUserProfile() {
		System.out.println("Get all values...");

		List<UserProfile> users = new ArrayList<>();
		repository.findAll().forEach(users::add);

		return users;
	}
}

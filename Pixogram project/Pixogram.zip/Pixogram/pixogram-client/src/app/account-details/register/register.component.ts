import { Component, OnInit } from '@angular/core';
import { User } from 'src/model/user';
import { Router } from '@angular/router';
import { UserAuthService } from 'src/services/user-auth.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  username: String;
  email: String;
  password: String;
  rPassword: String;
  invalidLogin: boolean = false;
  users: User[];

  constructor(private router: Router, private loginService: UserAuthService) { }

  ngOnInit() {
    this.loginService.getUsers().subscribe(response => this.users = response, error => alert(`${error.message}\nWaiting for response from server`));
    
  }

  onSubmit() {
    let user = new User(this.username, this.email, this.password);
    this.loginService.registerUser(user).subscribe(response => console.log(response));
  }
  checkUser()
  {

    for (let i = 0; i < this.users.length; i++) 
    {
      if (this.users[i].name === this.username )
      {
        this.invalidLogin=true;
      }
      else
      {
        this.invalidLogin=false;
      }
    }
  }
}

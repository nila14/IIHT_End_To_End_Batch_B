//package com.javasampleapproach.springrest.mysql.controller;
//
//import java.util.ArrayList;
//import java.util.List;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.web.bind.annotation.GetMapping;
//
//import com.javasampleapproach.springrest.mysql.model.Mentor;
//import com.javasampleapproach.springrest.mysql.model.Trainings;
//import com.javasampleapproach.springrest.mysql.repo.MentorRepository;
//import com.javasampleapproach.springrest.mysql.repo.TrainingsRepository;
//
//public class MentorController {
//	
//	@Autowired
//	MentorRepository repository;
//	@GetMapping("/mentor")
//	public List<Mentor> getmentors() {
//		System.out.println("Get all Trainings...");
//
//		List<Mentor> mentor = new ArrayList<>();
//		repository.findAll().forEach(mentor::add);
//
//		return mentor;
//	}
//}

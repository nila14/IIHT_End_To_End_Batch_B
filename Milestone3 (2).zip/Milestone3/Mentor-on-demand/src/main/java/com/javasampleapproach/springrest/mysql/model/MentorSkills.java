//package com.javasampleapproach.springrest.mysql.model;
//import javax.persistence.Column;
//import javax.persistence.Entity;
//import javax.persistence.GeneratedValue;
//import javax.persistence.GenerationType;
//import javax.persistence.Id;
//import javax.persistence.JoinColumn;
//import javax.persistence.ManyToOne;
//import javax.persistence.OneToMany;
//import javax.persistence.Table;
//
//@Entity
//@Table(name = "mentorskills")
//public class  MentorSkills {
//
//	@Id
//	@GeneratedValue(strategy = GenerationType.AUTO)
//	private long id;
//
//@ManyToOne
//@JoinColumn(name = "mid")
//	private long mid;
//
//	@Column(name = "sid")
//	private long sid;
//	
//	@Column(name = "self_rating")
//	private int self_rating;
//	
//	@Column(name = "years_of_experience")
//	private float years_of_experience;
//	
//	@Column(name = "trainings_delivered")
//	private String trainings_delivered;
//	
//	@Column(name = "facilities_offered")
//	private String facilities_offered;
//	
//	public MentorSkills(long id, long mid, long sid, int self_rating,float years_of_experience,
//			String trainings_delivered, String facilities_offered) {
//		super();
//		this.id = id;
//		this.mid = mid;
//		this.sid = sid;
//		this.self_rating = self_rating;
//		this.years_of_experience = years_of_experience;
//		this.trainings_delivered = trainings_delivered;
//		this.facilities_offered = facilities_offered;
//	}
//	
//
//	public long getId() {
//		return id;
//	}
//
//
//	public void setId(long id) {
//		this.id = id;
//	}
//
//
//	public long getMid() {
//		return mid;
//	}
//
//
//	public void setMid(long mid) {
//		this.mid = mid;
//	}
//
//
//	public long getSid() {
//		return sid;
//	}
//
//
//	public void setSid(long sid) {
//		this.sid = sid;
//	}
//
//
//	public int getSelf_rating() {
//		return self_rating;
//	}
//
//
//	public void setSelf_rating(int self_rating) {
//		this.self_rating = self_rating;
//	}
//
//
//	public float getYears_of_experience() {
//		return years_of_experience;
//	}
//
//
//	public void setYears_of_experience(float years_of_experience) {
//		this.years_of_experience = years_of_experience;
//	}
//
//
//	public String getTrainings_delivered() {
//		return trainings_delivered;
//	}
//
//
//	public void setTrainings_delivered(String trainings_delivered) {
//		this.trainings_delivered = trainings_delivered;
//	}
//
//
//	public String getFacilities_offered() {
//		return facilities_offered;
//	}
//
//
//	public void setFacilities_offered(String facilities_offered) {
//		this.facilities_offered = facilities_offered;
//	}
//
//
//	@Override
//	public String toString() {
//		return "Customer [id=" + id + ", mid=" + mid + "sid=" + sid + ", self_rating=" +  self_rating +",years_of_experience=" + years_of_experience +",trainings_delivered=" + trainings_delivered + ",facilities_offered=" + facilities_offered + "]";
//	}
//}
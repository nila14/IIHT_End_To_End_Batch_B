import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-addskill',
  templateUrl: './addskill.component.html',
  styleUrls: ['./addskill.component.css']
})
export class AddskillComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-manageuser',
  templateUrl: './manageuser.component.html',
  styleUrls: ['./manageuser.component.css']
})
export class ManageuserComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-managementor',
  templateUrl: './managementor.component.html',
  styleUrls: ['./managementor.component.css']
})
export class ManagementorComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-viewskills',
  templateUrl: './viewskills.component.html',
  styleUrls: ['./viewskills.component.css']
})
export class ViewskillsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { UsersignupComponent } from './usersignup/usersignup.component';
import { SigninComponent } from './signin/signin.component';
import { MentorsignupComponent } from './mentorsignup/mentorsignup.component';
import { AdminComponent } from './admin/admin.component';
import { ManageuserComponent } from './manageuser/manageuser.component';
import { ManagementorComponent } from './managementor/managementor.component';
import { AddskillComponent } from './addskill/addskill.component';
import { ViewskillsComponent } from './viewskills/viewskills.component';

const routes: Routes = [
  { path: '', component:SigninComponent, pathMatch: 'full' },
  {path :'usersignup',component:UsersignupComponent},
  {path :'mentorsignup',component:MentorsignupComponent},
  {path:'admin',component:AdminComponent },
  {path:'manageuser',component:ManageuserComponent},
  {path:'managementor',component:ManagementorComponent},
  {path:'addskill',component:AddskillComponent},
  {path:'viewskills',component:ViewskillsComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

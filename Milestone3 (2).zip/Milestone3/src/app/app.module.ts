import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { SigninComponent } from './signin/signin.component';
import { UsersignupComponent } from './usersignup/usersignup.component';
import { MentorsignupComponent } from './mentorsignup/mentorsignup.component';
import { AdminComponent } from './admin/admin.component';
import { ManageuserComponent } from './manageuser/manageuser.component';
import { ManagementorComponent } from './managementor/managementor.component';
import { AddskillComponent } from './addskill/addskill.component';
import { ViewskillsComponent } from './viewskills/viewskills.component';

@NgModule({
  declarations: [
    AppComponent,
    SigninComponent,
    UsersignupComponent,
    MentorsignupComponent,
    AdminComponent,
    ManageuserComponent,
    ManagementorComponent,
    AddskillComponent,
    ViewskillsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }

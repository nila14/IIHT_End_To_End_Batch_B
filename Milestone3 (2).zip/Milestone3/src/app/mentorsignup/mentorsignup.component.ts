import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mentorsignup',
  templateUrl: './mentorsignup.component.html',
  styleUrls: ['./mentorsignup.component.css']
})
export class MentorsignupComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
